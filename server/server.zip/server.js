// const http = require("http");
// const express = require("express");
// const { WebSocketServer } = require("ws");
// const IORedis = require("ioredis");
// const { Pool } = require("pg");
// const { Message } = require("./models/Message.js");
// const { sequelize } = require("./bd.js");

// const PORT = process.env.PORT || 3000;

// const pool = new Pool({
//   host: process.env.POSTGRES_HOST || "postgres",
//   port: Number(process.env.POSTGRES_PORT || 5432),
//   user: process.env.POSTGRES_USER || "app",
//   password: process.env.POSTGRES_PASSWORD || "app_password",
//   database: process.env.POSTGRES_DB || "appdb",
// });

// const redisHost = process.env.REDIS_HOST || "redis";
// const redisPort = Number(process.env.REDIS_PORT || 6379);
// const sub = new IORedis(redisPort, redisHost);
// const pub = new IORedis(redisPort, redisHost);

// async function ensureSchema() {
//   const client = await pool.connect();
//   try {
//     await client.query("BEGIN");

//     await client.query(`
//       CREATE TABLE IF NOT EXISTS users (
//         id SERIAL PRIMARY KEY,
//         email VARCHAR(255) UNIQUE NOT NULL,
//         password_hash VARCHAR(255) NOT NULL,
//         first_name VARCHAR(100) NOT NULL,
//         last_name VARCHAR(100) NOT NULL,
//         user_type VARCHAR(20) CHECK (user_type IN ('patient','doctor','admin')),
//         avatar_url VARCHAR(500),
//         is_online BOOLEAN DEFAULT false,
//         last_online TIMESTAMPTZ,
//         created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//       );
//     `);

//     await client.query(`
//       CREATE TABLE IF NOT EXISTS chat_rooms (
//         id SERIAL PRIMARY KEY,
//         room_type VARCHAR(20) CHECK (room_type IN ('dialog','group')) DEFAULT 'dialog',
//         title VARCHAR(255),
//         created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
//         created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//       );
//     `);

//     await client.query(`
//       CREATE TABLE IF NOT EXISTS patients (
//         id SERIAL PRIMARY KEY,
//         user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
//         date_of_birth DATE,
//         gender VARCHAR(20),
//         phone_number VARCHAR(50),
//         emergency_contact VARCHAR(255),
//         medical_history TEXT,
//         allergies TEXT
//       );
//     `);

//     await client.query(`
//       CREATE TABLE IF NOT EXISTS doctors (
//         id SERIAL PRIMARY KEY,
//         user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
//         specialization VARCHAR(200),
//         license_number VARCHAR(100),
//         experience_years INTEGER,
//         rating DECIMAL(3,2) DEFAULT 0.0,
//         consultation_price DECIMAL(10,2),
//         description TEXT,
//         is_verified BOOLEAN DEFAULT false
//       );
//     `);

//     await client.query(`
//       CREATE TABLE IF NOT EXISTS messages (
//         id SERIAL PRIMARY KEY,
//         room_id INTEGER REFERENCES chat_rooms(id) ON DELETE CASCADE,
//         sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
//         message_text TEXT,
//         message_type VARCHAR(20) CHECK (message_type IN ('text','image','file','system')) DEFAULT 'text',
//         file_url VARCHAR(500),
//         file_name VARCHAR(255),
//         file_size INTEGER,
//         is_read BOOLEAN DEFAULT false,
//         read_at TIMESTAMPTZ,
//         created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//         deleted_at TIMESTAMPTZ
//       );

//       CREATE INDEX IF NOT EXISTS idx_messages_room_id ON messages(room_id);
//       CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
//     `);

//     await client.query(`
//       CREATE TABLE IF NOT EXISTS read_receipts (
//         id SERIAL PRIMARY KEY,
//         message_id INTEGER REFERENCES messages(id) ON DELETE CASCADE,
//         user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
//         read_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//         UNIQUE (message_id, user_id)
//       );
//     `);

//     await client.query(`
//       CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER AS $$
//       BEGIN
//         NEW.updated_at = NOW();
//         RETURN NEW;
//       END; $$ LANGUAGE plpgsql;

//       DO $$
//       BEGIN
//         IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'users_set_updated_at') THEN
//           CREATE TRIGGER users_set_updated_at BEFORE UPDATE ON users
//           FOR EACH ROW EXECUTE FUNCTION set_updated_at();
//         END IF;
//         IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'chat_rooms_set_updated_at') THEN
//           CREATE TRIGGER chat_rooms_set_updated_at BEFORE UPDATE ON chat_rooms
//           FOR EACH ROW EXECUTE FUNCTION set_updated_at();
//         END IF;
//         IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'messages_set_updated_at') THEN
//           CREATE TRIGGER messages_set_updated_at BEFORE UPDATE ON messages
//           FOR EACH ROW EXECUTE FUNCTION set_updated_at();
//         END IF;
//       END $$;
//     `);

//     await client.query("COMMIT");
//   } catch (e) {
//     await client.query("ROLLBACK");
//     throw e;
//   } finally {
//     client.release();
//   }
// }

// const app = express();
// app.get("/health", async (_req, res) => {
//   try {
//     await pool.query("SELECT 1");
//     res.status(200).json({ ok: true });
//   } catch (e) {
//     res.status(500).json({ ok: false });
//   }
// });

// const server = http.createServer(app);
// const wss = new WebSocketServer({ server });
// const clients = new Set();

// wss.on("connection", (ws) => {
//   ws.isAlive = true;
//   clients.add(ws);

//   ws.on("pong", () => (ws.isAlive = true));

//   ws.send(JSON.stringify({ type: "hello", msg: "connected" }));

//   ws.on("message", async (raw) => {
//     try {
//       const str = raw.toString();
//       // await pool.query("INSERT INTO messages(body) VALUES($1)", [str]);

//       await Message.create({
//         body: raw.toString(),
//         userId: "maksym@example.com",
//         fromUser: "333",
//         isRead: true,
//       });

//       await pub.publish("chat", str);
//     } catch (e) {
//       ws.send(JSON.stringify({ type: "error", error: e.message }));
//     }
//   });

//   ws.on("close", () => clients.delete(ws));
// });

// sub.subscribe("chat");
// sub.on("message", (_channel, payload) => {
//   for (const client of clients) {
//     if (client.readyState === 1)
//       client.send(JSON.stringify({ type: "msg", body: payload }));
//   }
// });

// setInterval(() => {
//   for (const ws of clients) {
//     if (!ws.isAlive) {
//       ws.terminate();
//       clients.delete(ws);
//       continue;
//     }
//     ws.isAlive = false;
//     ws.ping();
//   }
// }, 30000);

// (async () => {
//   await ensureSchema();
//   try {
//     await sequelize.authenticate();
//     console.log("Connection has been established successfully.");
//   } catch (error) {
//     console.error("Unable to connect to the database:", error);
//   }
//   server.listen(PORT, () => {
//     console.log(`HTTP+WS up on :${PORT}`);
//   });
// })();

import express from "express";
import http from "http";
import { Server } from "socket.io";
import { Pool } from "pg";
import { setupSocketHandlers } from "./services/socketService.js";
import { authenticateSocket } from "./middleware/auth.js";
import jwt from "jsonwebtoken";

// import authRoutes from "./routes/auth";

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

export const pool = new Pool({
  host: process.env.POSTGRES_HOST || "postgres",
  port: Number(process.env.POSTGRES_PORT || 5432),
  user: process.env.POSTGRES_USER || "app",
  password: process.env.POSTGRES_PASSWORD || "app_password",
  database: process.env.POSTGRES_DB || "appdb",
});

const doctorToken = jwt.sign(
  { id: 1, email: "doctor1@example.com", user_type: "doctor" },
  "your-secret-key",
  { expiresIn: "240d" }
);

// Генерация токена для пациента
const patientToken = jwt.sign(
  { id: 3, email: "patient1@example.com", user_type: "patient" },
  "your-secret-key",
  { expiresIn: "240d" }
);

console.log("Doctor token:", doctorToken);
console.log("Patient token:", patientToken);

app.use(express.json());
// app.use("/auth", authRoutes);

io.use(authenticateSocket);

setupSocketHandlers(io);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
