import { ChatService } from "./chatService.js";

const chatService = new ChatService();

export const setupSocketHandlers = (io) => {
  io.on("connection", (socket) => {
    console.log("User connected:", socket.data.user.id);

    // Присоединение к комнате чата
    socket.on("join_chat", async (data) => {
      const dating = JSON.parse(data);
      const { roomId } = dating;
      const userId = socket.data.user.id;

      try {
        const canJoin = await chatService.canUserJoinRoom(roomId, userId);

        console.log("User joining chat:", canJoin);
        if (canJoin) {
          socket.join(`room_${roomId}`);
          console.log("Joined room successfully:", `room_${roomId}`);
          socket.emit("join_success", { roomId: parseInt(roomId) });
          console.log("join_success emitted");

          // Отправляем историю сообщений
          const messages = await chatService.getRoomMessages(roomId);
          socket.emit("message_history", messages);
        } else {
          socket.emit("join_error", { message: "Access denied" });
        }
      } catch (error) {
        socket.emit("join_error", { message: "Error joining room" });
      }
    });
    socket.on("ping", (data) => {
      console.log("ping received:", data);
      socket.emit("pong", { message: "pong", received: data });
    });
    // Отправка сообщения
    socket.on("send_message", async (data) => {
      const dating = JSON.parse(data);
      const { roomId, text, type = "text" } = dating;
      const senderId = socket.data.user.id;

      try {
        const message = await chatService.createMessage({
          roomId,
          senderId,
          text,
          type,
        });

        // Отправляем сообщение всем в комнате
        io.to(`room_${roomId}`).emit("new_message", message);

        // Отправляем уведомление другому участнику, если он offline
        const otherUserId = await chatService.getOtherRoomParticipant(
          roomId,
          senderId
        );
        if (otherUserId) {
          const isOnline = await chatService.isUserOnline(otherUserId);
          if (!isOnline) {
            // Сохраняем уведомление в БД
            await chatService.createNotification({
              userId: otherUserId,
              type: "new_message",
              title: "Новое сообщение",
              message: `У вас новое сообщение в чате`,
            });
          }
        }
      } catch (error) {
        socket.emit("message_error", { message: "Error sending message" });
      }
    });

    // Отметка сообщений как прочитанных
    socket.on("mark_as_read", async (data) => {
      const { messageIds } = data;
      const userId = socket.data.user.id;

      try {
        await chatService.markMessagesAsRead(messageIds, userId);

        // Уведомляем других участников о прочтении
        messageIds.forEach((messageId) => {
          socket.broadcast.emit("messages_read", {
            messageId,
            userId,
          });
        });
      } catch (error) {
        socket.emit("read_error", {
          message: "Error marking messages as read",
        });
      }
    });

    // Обработка отключения
    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.data.user.id);
      chatService.updateUserStatus(socket.data.user.id, false);
    });

    // Обновление статуса онлайн
    socket.on("user_online", () => {
      chatService.updateUserStatus(socket.data.user.id, true);
    });

    // Typing indicator
    socket.on("typing_start", (data) => {
      socket.to(`room_${data.roomId}`).emit("user_typing", {
        userId: socket.data.user.id,
        isTyping: true,
      });
    });

    socket.on("typing_stop", (database) => {
      socket.to(`room_${data.roomId}`).emit("user_typing", {
        userId: socket.data.user.id,
        isTyping: false,
      });
    });
  });
};
