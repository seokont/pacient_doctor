const { sequelize } = require("../bd.js");
const { DataTypes, Sequelize: Seq } = require("sequelize");

const Patients = sequelize.define(
  "Patients",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    userId: { type: DataTypes.STRING(20), allowNull: false },
    dateOfBirth: { type: DataTypes.DATEONLY, allowNull: false },
    gender: { type: DataTypes.STRING(20), allowNull: false },
    phoneNumber: { type: DataTypes.STRING(20), allowNull: false },
    emergencyContact: { type: DataTypes.STRING(255), allowNull: false },
    medicalHistory: { type: DataTypes.TEXT, allowNull: false },
    allergies: { type: DataTypes.TEXT, allowNull: false },

    createdAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
    updatedAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
  },
  {
    tableName: "patients",
    timestamps: true,
    underscored: true,
  }
);

module.exports = { Patients };
