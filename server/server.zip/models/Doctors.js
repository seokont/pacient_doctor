const { sequelize } = require("../bd.js");
const { DataTypes, Sequelize: Seq } = require("sequelize");

const Doctors = sequelize.define(
  "Doctors",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    userId: { type: DataTypes.STRING(20), allowNull: false },
    specialization: { type: DataTypes.STRING(200), allowNull: false },
    licenseNumber: { type: DataTypes.STRING(100), allowNull: false },
    experienceYears: { type: DataTypes.INTEGER, allowNull: false },
    rating: {
      type: DataTypes.DECIMAL(3, 2),
      allowNull: false,
      defaultValue: 0.0,
    },
    consultationPrice: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
    description: { type: DataTypes.TEXT, allowNull: false },
    is_verified: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },

    createdAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
    updatedAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
  },
  {
    tableName: "doctors",
    timestamps: true,
    underscored: true,
  }
);

module.exports = { Doctors };
