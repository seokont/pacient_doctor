const { sequelize } = require("../bd.js");
const { DataTypes, Sequelize: Seq } = require("sequelize");

const ReadReceipts = sequelize.define(
  "ReadReceipts",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    messageId: {
      type: DataTypes.INTEGER,
      references: { model: "messages", key: "id" },
      allowNull: false,
      onDelete: "CASCADE",
    },
    userId: {
      type: DataTypes.INTEGER,
      references: { model: "users", key: "id" },
      allowNull: false,
      onDelete: "CASCADE",
    },
    readAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },

    createdAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
    updatedAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
  },
  {
    tableName: "read_receipts",
    timestamps: true,
    underscored: true,
  }
);

module.exports = { ReadReceipts };
