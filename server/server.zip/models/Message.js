const { sequelize } = require("../bd.js");
const { DataTypes, Sequelize: Seq } = require("sequelize");

const Message = sequelize.define(
  "Message",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    roomId: {
      type: DataTypes.INTEGER,
      references: { model: "rooms", key: "id" },
      onDelete: "CASCADE",
      allowNull: false,
    },
    senderId: {
      type: DataTypes.INTEGER,
      references: { model: "users", key: "id" },
      onDelete: "CASCADE",
      allowNull: false,
    },
    messageText: { type: DataTypes.TEXT, allowNull: false },
    messageType: { type: DataTypes.STRING(20), allowNull: false },
    fileUrl: {
      type: DataTypes.STRING(500),
      allowNull: true,
    },
    fileName: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    fileSize: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    isRead: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
  },
  {
    tableName: "messages",
    timestamps: true,
    underscored: true,
  }
);

module.exports = { Message };
