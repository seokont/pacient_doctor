const { sequelize } = require("../bd.js");
const { DataTypes, Sequelize: Seq } = require("sequelize");

const ChatRoom = sequelize.define(
  "ChatRoom",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    roomType: { type: DataTypes.STRING(20), allowNull: false },
    title: { type: DataTypes.STRING(255), allowNull: false },

    createdAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
    updatedAt: {
      type: DataTypes.TIMESTAMP,
      defaultValue: Seq.literal("CURRENT_TIMESTAMP"),
    },
  },
  {
    tableName: "chat_rooms",
    timestamps: true,
    underscored: true,
  }
);

module.exports = { ChatRoom };
