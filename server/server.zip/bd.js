const { Sequelize } = require("sequelize");

const sequelize = new Sequelize("appdb", "app", "app_password", {
  host: "postgres",
  port: 5432,
  dialect: "postgres",
  logging: false,
});

module.exports = { sequelize };
